# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
u = input('Please enter currency in USD: ')
n = u*30
print 'The equivalent NTD is: ' + str(n)



